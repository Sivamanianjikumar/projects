<?php 
	$con=mysqli_connect("localhost","root","Deepika@123","db_birthday_reminder");
	// $reminder_con=mysqli_connect("localhost","root","Deepika@123","reminders");
?>